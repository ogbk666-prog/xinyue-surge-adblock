# BiliSkip build pipeline
#   logos expand -> fix #line -> ctor postprocess -> zig cross-compile -> deb / troll dylib
#
# targets:
#   1) rootful   deb  iphoneos-arm     (/Library/MobileSubstrate/DynamicLibraries)
#   2) rootless  deb  iphoneos-arm64   (/var/jb/...)
#   3) troll     bare dylib, no substrate (TrollStore + TrollFools)
#
# usage: powershell -NoProfile -ExecutionPolicy Bypass -File build.ps1
$ErrorActionPreference = 'Stop'

$WS    = 'C:\Users\Administrator\Documents\deepseek-harness\default-workspace'
$PROJ  = Join-Path $WS 'xinyue\bsbskip'
$TOOL  = Join-Path $WS 'xinyue\toolchain'
$OUT   = Join-Path $PROJ 'build'
$SDK   = Join-Path $TOOL 'sdks\iPhoneOS14.5.sdk'
$PERL  = 'C:\Strawberry\perl\bin\perl.exe'
$LOGOS = Join-Path $TOOL 'logos\bin\logos.pl'
$ZIG   = Join-Path $TOOL 'zig.exe'
$PY    = 'C:\Users\Administrator\AppData\Local\Programs\DSH Desktop\resources\office-runtime\primary-runtime\dependencies\python\python.exe'

$TWEAK = 'BiliSkip'
New-Item -ItemType Directory -Force -Path $OUT | Out-Null
$env:PYTHONIOENCODING  = 'utf-8'
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $OUT 'zigcache'
$env:ZIG_LOCAL_CACHE_DIR  = Join-Path $OUT 'zigcache'

if (-not (Test-Path $ZIG)) { throw "zig 不在 $ZIG" }
if (-not (Test-Path $SDK)) { throw "SDK 不在 $SDK" }
if (-not (Test-Path $LOGOS)) { throw "logos.pl 不在 $LOGOS" }
if (-not (Test-Path $PERL)) { throw "perl 不在 $PERL" }

function Expand-Source([string]$generator, [string]$outFile) {
    if ($generator) {
        cmd /c "`"$PERL`" `"$LOGOS`" -c generator=$generator `"$PROJ\Tweak.xm`" > `"$outFile`""
    } else {
        cmd /c "`"$PERL`" `"$LOGOS`" `"$PROJ\Tweak.xm`" > `"$outFile`""
    }
    if ($LASTEXITCODE -ne 0) { throw "logos expand failed ($generator)" }
    if (-not (Test-Path $outFile)) { throw "logos 没产出 $outFile" }

    # #line 里的 Windows 反斜杠会让 clang 报错
    $txt   = [System.IO.File]::ReadAllText($outFile)
    $fixed = [regex]::Replace($txt, '(#line\s+\d+\s+")([^"]*)(")', {
        param($m) $m.Groups[1].Value + $m.Groups[2].Value.Replace('\','/') + $m.Groups[3].Value })
    [System.IO.File]::WriteAllText($outFile, $fixed, (New-Object System.Text.UTF8Encoding($false)))

    & $PY (Join-Path $WS 'xinyue\postprocess.py') $outFile --prefix $TWEAK --label $TWEAK
    if ($LASTEXITCODE -ne 0) { throw 'postprocess failed' }
}

function Build-Dylib([string]$src, [string]$outFile, [string]$installName) {
    $cargs = @('cc','-target','aarch64-ios.14.0',
        '-isysroot', $SDK,
        '-isystem', "$SDK\usr\include",
        '-L', "$SDK\usr\lib",
        '-F', "$SDK\System\Library\Frameworks",
        '-I', $OUT,
        '-fobjc-arc','-fblocks',
        '-dynamiclib','-undefined','dynamic_lookup',
        '-Wl,-headerpad,0x400',
        '-install_name', $installName,
        '-w','-O2',
        '-o', $outFile, $src)
    & $ZIG @cargs
    if ($LASTEXITCODE -ne 0) { throw "compile failed: $outFile" }
    return (Get-Item $outFile).Length
}

Write-Host '=== A. 越狱（substrate 后端）==='
Expand-Source $null "$OUT\Tweak.mm"
$s1 = Build-Dylib "$OUT\Tweak.mm" "$OUT\$TWEAK.dylib" "/Library/MobileSubstrate/DynamicLibraries/$TWEAK.dylib"
$s2 = Build-Dylib "$OUT\Tweak.mm" "$OUT\$TWEAK-rootless.dylib" "/var/jb/Library/MobileSubstrate/DynamicLibraries/$TWEAK.dylib"
Write-Host "  rootful  -> $s1 bytes"
Write-Host "  rootless -> $s2 bytes"

Write-Host '=== B. TrollStore（internal 后端，零 substrate 依赖）==='
Expand-Source 'internal' "$OUT\Tweak.troll.mm"
$s3 = Build-Dylib "$OUT\Tweak.troll.mm" "$OUT\$TWEAK-Troll.dylib" "@executable_path/$TWEAK.dylib"
Write-Host "  troll    -> $s3 bytes"

Write-Host '=== C. 打包 ==='
& $PY (Join-Path $PROJ 'make_deb.py')
if ($LASTEXITCODE -ne 0) { throw 'deb 打包失败' }

Write-Host ''
Write-Host 'BUILD OK:'
Get-ChildItem "$OUT\*.dylib","$OUT\*.deb" | ForEach-Object { "  {0,-42} {1,8} bytes" -f $_.Name, $_.Length }
