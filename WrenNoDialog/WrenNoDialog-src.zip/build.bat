@echo off
setlocal
REM ==========================================================
REM  Build LSPosed module APK without Gradle
REM  javac -> d8 -> aapt2 -> jar -> zipalign -> apksigner
REM ==========================================================

set ROOT=%~dp0
set TOOLS=%ROOT%..\tools
set BUILD=%ROOT%build
set JDK=%ROOT%..\jdk\jdk-17.0.2
set BT=%TOOLS%\build-tools\android-14
set ANDROID_JAR=%TOOLS%\platform-34\android-34\android.jar

if not exist "%JDK%\bin\javac.exe" goto nojdk
if not exist "%ANDROID_JAR%" goto nojar
if not exist "%BT%\d8.bat" goto nobt

set JAVA_HOME=%JDK%
set PATH=%JDK%\bin;%PATH%

if exist "%BUILD%" rmdir /s /q "%BUILD%"
mkdir "%BUILD%\stubclasses" 2>nul
mkdir "%BUILD%\classes" 2>nul
mkdir "%BUILD%\dex" 2>nul
mkdir "%BUILD%\apk" 2>nul
mkdir "%BUILD%\resout" 2>nul

echo [1/7] compile Xposed API stubs
"%JDK%\bin\javac.exe" -encoding UTF-8 -source 8 -target 8 -nowarn -d "%BUILD%\stubclasses" "%ROOT%stub\de\robv\android\xposed\IXposedHookLoadPackage.java" "%ROOT%stub\de\robv\android\xposed\XC_MethodHook.java" "%ROOT%stub\de\robv\android\xposed\XposedBridge.java" "%ROOT%stub\de\robv\android\xposed\XposedHelpers.java" "%ROOT%stub\de\robv\android\xposed\callbacks\XC_LoadPackage.java"
if errorlevel 1 goto fail

echo [2/7] compile module source
"%JDK%\bin\javac.exe" -encoding UTF-8 -source 8 -target 8 -nowarn -cp "%BUILD%\stubclasses;%ANDROID_JAR%" -d "%BUILD%\classes" "%ROOT%src\com\lcs\wrennodialog\HookEntry.java"
if errorlevel 1 goto fail

echo [3/7] d8 to dex
call "%BT%\d8.bat" --release --min-api 24 --lib "%ANDROID_JAR%" --lib "%BUILD%\stubclasses" --output "%BUILD%\dex" "%BUILD%\classes\com\lcs\wrennodialog\HookEntry.class"
if errorlevel 1 goto fail

echo [4/7] aapt2 compile resources
"%BT%\aapt2.exe" compile --dir "%ROOT%res" -o "%BUILD%\resout\res.zip"
if errorlevel 1 goto fail

echo [5/7] aapt2 link
"%BT%\aapt2.exe" link -o "%BUILD%\apk\base.apk" -I "%ANDROID_JAR%" --manifest "%ROOT%AndroidManifest.xml" --min-sdk-version 24 --target-sdk-version 34 -A "%ROOT%assets" "%BUILD%\resout\res.zip"
if errorlevel 1 goto fail

echo [6/7] add classes.dex
pushd "%BUILD%\dex"
"%JDK%\bin\jar.exe" uf "%BUILD%\apk\base.apk" classes.dex
popd

echo [7/7] zipalign and sign
"%BT%\zipalign.exe" -f 4 "%BUILD%\apk\base.apk" "%BUILD%\apk\aligned.apk"
if errorlevel 1 goto fail

if not exist "%ROOT%sign" mkdir "%ROOT%sign"
if not exist "%ROOT%sign\key.jks" (
  "%JDK%\bin\keytool.exe" -genkeypair -v -keystore "%ROOT%sign\key.jks" -alias wrennodialog -keyalg RSA -keysize 2048 -validity 10000 -storepass wren123456 -keypass wren123456 -dname "CN=WrenNoDialog,OU=Local,O=Local,L=Local,S=Local,C=CN"
)

call "%BT%\apksigner.bat" sign --ks "%ROOT%sign\key.jks" --ks-pass pass:wren123456 --key-pass pass:wren123456 --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true --out "%ROOT%WrenNoDialog.apk" "%BUILD%\apk\aligned.apk"
if errorlevel 1 goto fail

echo.
echo ===== DONE =====
dir "%ROOT%WrenNoDialog.apk"
goto end

:nojdk
echo [!] JDK not found at %JDK%
goto fail
:nojar
echo [!] android.jar not found at %ANDROID_JAR%
goto fail
:nobt
echo [!] d8.bat not found at %BT%
goto fail

:fail
echo [!] BUILD FAILED
exit /b 1

:end
exit /b 0
