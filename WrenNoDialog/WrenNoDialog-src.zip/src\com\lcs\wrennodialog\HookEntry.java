package com.lcs.wrennodialog;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Wren 赞助弹窗屏蔽 —— LSPosed 模块。
 *
 * 目标：top.haif.xposed（Wren · 微信功能增强）
 *
 * 为什么钩 Dialog.show：
 *   那个「支持一下?❤️ / 去赞助 / 先不考虑」是自定义 Dialog（圆角卡片 + 蓝灰按钮），
 *   不是原生 AlertDialog。反编译确认全包 Dialog->show 只有一处调用点。
 *
 * 拦截策略：
 *   1. AlertDialog 及其子类一律放过 —— 功能开关、wxid 输入框都用它
 *   2. 只拦挂在 Activity 上的自定义 Dialog
 *   3. Toast 完全不碰
 *
 * 想临时关掉：LSPosed 里取消勾选作用域，不用改代码。
 *
 * 注意：全部用反射访问 Android 类，编译时不依赖 android.jar。
 */
public class HookEntry implements IXposedHookLoadPackage {

    private static final String TAG = "[WrenNoDialog] ";
    private static final String TARGET_PKG = "top.haif.xposed";

    /** 打开后会在 LSPosed 日志里打印每次 show 的类名，方便核对 */
    private static final boolean DEBUG_LOG = true;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (lpparam == null || !TARGET_PKG.equals(lpparam.packageName)) {
            return;
        }

        XposedBridge.log(TAG + "命中 " + lpparam.packageName
                + "  process=" + lpparam.processName
                + "  first=" + lpparam.isFirstApplication);

        final ClassLoader cl = lpparam.classLoader;

        try {
            Class<?> dialogClass = Class.forName("android.app.Dialog", false, cl);
            final Class<?> alertClass = Class.forName("android.app.AlertDialog", false, cl);
            final Class<?> activityClass = Class.forName("android.app.Activity", false, cl);

            XposedHelpers.findAndHookMethod(dialogClass, "show", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    Object self = param.thisObject;
                    if (self == null) return;

                    String cls = self.getClass().getName();

                    // 1) 原生/子类 AlertDialog 放过（功能弹窗都用它）
                    if (alertClass.isInstance(self)) {
                        if (DEBUG_LOG) log("放过 AlertDialog -> " + cls);
                        return;
                    }

                    // 2) 只处理挂在 Activity 上的（真弹窗）
                    if (!isActivityDialog(self, activityClass)) {
                        if (DEBUG_LOG) log("放过非 Activity Dialog -> " + cls);
                        return;
                    }

                    // 3) 自定义 Dialog，吞掉
                    log("拦住 -> " + cls);
                    param.setResult(null);
                }
            });

            XposedBridge.log(TAG + "已挂上 Dialog.show");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook 失败: " + t);
            XposedBridge.log(t);
        }
    }

    private static void log(String s) {
        XposedBridge.log(TAG + s);
    }

    /** 拿 getContext() 判断是不是 Activity 挂着的 Dialog；拿不到就当是 */
    private static boolean isActivityDialog(Object dialog, Class<?> activityClass) {
        try {
            Method m = dialog.getClass().getMethod("getContext");
            m.setAccessible(true);
            Object ctx = m.invoke(dialog);
            if (ctx == null) return true;
            return activityClass.isInstance(ctx);
        } catch (Throwable ignored) {
            return true;
        }
    }
}
