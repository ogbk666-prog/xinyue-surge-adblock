"""BiliSkip deb 打包：手搓 ar + control.tar.gz + data.tar.gz（不依赖 dpkg-deb）。"""
import io
import os
import sys
import gzip
import tarfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "build")

PKG = "com.littlecodesauce.biliskip"
NAME = "BiliSkip"
VERSION = "0.1.0"
ARCH_R = "iphoneos-arm"
ARCH_N = "iphoneos-arm64"

CONTROL = """Package: {pkg}
Name: {name}
Version: {ver}
Architecture: {arch}
Description: 哔哩哔哩自动空降 —— 接入 bsbsb.top 社区标注，播放时自动跳过推广片段
Maintainer: Little Code Sauce
Author: Little Code Sauce
Section: Tweaks
Depends: mobilesubstrate, firmware (>= 14.0)
"""

CONTROL_ROOTLESS = """Package: {pkg}
Name: {name}
Version: {ver}
Architecture: {arch}
Description: 哔哩哔哩自动空降 —— 接入 bsbsb.top 社区标注，播放时自动跳过推广片段
Maintainer: Little Code Sauce
Author: Little Code Sauce
Section: Tweaks
Depends: mobilesubstrate, firmware (>= 15.0)
"""

PLIST = """{{ Filter = {{ Bundles = ( "tv.danmaku.bilianime" ); }}; }}
"""


def tar_bytes(entries):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.GNU_FORMAT) as tf:
        for name, data, mode in entries:
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = mode
            info.uid = info.gid = 0
            info.uname = info.gname = "root"
            info.mtime = 1750000000
            tf.addfile(info, io.BytesIO(data))
    return buf.getvalue()


def gz(data):
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", mtime=0) as g:
        g.write(data)
    return buf.getvalue()


def ar_archive(members):
    out = io.BytesIO()
    out.write(b"!<arch>\n")
    for name, data in members:
        header = "{:<16}{:<12}{:<6}{:<6}{:<8}{:<10}`\n".format(
            name, 0, 0, 0, 100644, len(data)
        ).encode("ascii")
        out.write(header)
        out.write(data)
        if len(data) % 2:
            out.write(b"\n")
    return out.getvalue()


def build(rootless=False):
    dylib = os.path.join(OUT, "BiliSkip-rootless.dylib" if rootless else "BiliSkip.dylib")
    if not os.path.exists(dylib):
        print(f"[!] 缺 dylib: {dylib}")
        return False

    base = "/var/jb" if rootless else ""
    libdir = f"{base}/Library/MobileSubstrate/DynamicLibraries"

    with open(dylib, "rb") as f:
        dylib_data = f.read()

    entries = [
        ("./", b"", 0o755),
        (f".{libdir}/", b"", 0o755),
        (f".{libdir}/BiliSkip.dylib", dylib_data, 0o644),
        (f".{libdir}/BiliSkip.plist", PLIST.encode(), 0o644),
    ]
    data_tar = gz(tar_bytes(entries))

    arch = ARCH_N if rootless else ARCH_R
    ctrl_text = (CONTROL_ROOTLESS if rootless else CONTROL).format(
        pkg=PKG, name=NAME, ver=VERSION, arch=arch
    )
    ctrl_tar = gz(tar_bytes([("./control", ctrl_text.encode(), 0o644)]))

    deb = ar_archive([
        ("debian-binary", b"2.0\n"),
        ("control.tar.gz", ctrl_tar),
        ("data.tar.gz", data_tar),
    ])

    suffix = "arm64" if rootless else "arm"
    out_path = os.path.join(OUT, f"BiliSkip_{VERSION}_{suffix}.deb")
    with open(out_path, "wb") as f:
        f.write(deb)
    print(f"  ✔ {os.path.basename(out_path)}  {len(deb)} 字节  ({arch})")
    return True


if __name__ == "__main__":
    ok1 = build(False)
    ok2 = build(True)
    sys.exit(0 if (ok1 and ok2) else 1)
