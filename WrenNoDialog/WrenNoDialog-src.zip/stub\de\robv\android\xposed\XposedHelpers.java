package de.robv.android.xposed;

/** 编译期 stub。 */
public class XposedHelpers {
    public static void findAndHookMethod(Class<?> clazz, String methodName, Object... parameterTypesAndCallback) {}
    public static void findAndHookMethod(String className, ClassLoader classLoader, String methodName, Object... parameterTypesAndCallback) {}
    public static void findAndHookConstructor(Class<?> clazz, Object... parameterTypesAndCallback) {}
    public static Object getObjectField(Object obj, String fieldName) { return null; }
    public static void setObjectField(Object obj, String fieldName, Object value) {}
    public static Object callMethod(Object obj, String methodName, Object... args) { return null; }
    public static boolean getBooleanField(Object obj, String fieldName) { return false; }
}