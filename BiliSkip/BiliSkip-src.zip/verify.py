import struct, sys, os

def parse_macho(path):
    data = open(path, "rb").read()
    magic = struct.unpack("<I", data[:4])[0]
    if magic != 0xFEEDFACF:
        return {"error": f"不是 64 位 Mach-O (magic=0x{magic:08x})"}

    cputype, cpusub, ftype, ncmds, sizeofcmds, flags, _ = struct.unpack("<iiIIIII", data[4:32])
    segs, sections = [], []
    off = 32
    for _ in range(ncmds):
        cmd, cmdsize = struct.unpack("<II", data[off:off+8])
        if cmd == 0x19:  # LC_SEGMENT_64
            segname = data[off+8:off+24].rstrip(b"\x00").decode()
            nsects = struct.unpack("<I", data[off+64:off+68])[0]
            segs.append(segname)
            soff = off + 72
            for _ in range(nsects):
                sectname = data[soff:soff+16].rstrip(b"\x00").decode()
                segn = data[soff+16:soff+32].rstrip(b"\x00").decode()
                size = struct.unpack("<Q", data[soff+40:soff+48])[0]
                sections.append((segn, sectname, size))
                soff += 80
        off += cmdsize

    text = data.decode("latin1")
    return {
        "arch": "arm64" if cputype == 0x0100000C else hex(cputype),
        "filetype": ftype,
        "segments": segs,
        "sections": sections,
        "size": len(data),
        "has_mshook": "MSHookMessageEx" in text,
        "has_method_set": "method_setImplementation" in text,
        "has_prefix": "BiliSkip_done" in text,
        "has_loader": "BiliSkip_Loader" in text,
        "has_ctor": "_logosLocalCtor" in text,
        "undef_substrate": "substrate" in text.lower(),
    }

def main():
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build")
    targets = ["BiliSkip.dylib", "BiliSkip-rootless.dylib", "BiliSkip-Troll.dylib"]
    ok = True
    for name in targets:
        p = os.path.join(base, name)
        if not os.path.exists(p):
            print(f"  ✘ 缺文件 {name}"); ok = False; continue
        r = parse_macho(p)
        print(f"\n=== {name} ===")
        print(f"  arch={r['arch']}  size={r['size']}B  segments={r['segments']}")
        modinit = [s for s in r["sections"] if s[1] == "__mod_init_func"]
        for segn, sect, size in modinit:
            mark = "✔ dyld 会扫的 __DATA" if segn == "__DATA" else "△ 在 __DATA_CONST，靠 ObjC +load 兜底"
            print(f"  __mod_init_func 位于 {segn},{sect}  {size}B   {mark}")
        print(f"  MSHookMessageEx : {r['has_mshook']}")
        print(f"  method_setImpl  : {r['has_method_set']}")
        print(f"  BiliSkip_done   : {r['has_prefix']}")
        print(f"  BiliSkip_Loader : {r['has_loader']}")
        if "Troll" in name and r["has_mshook"]:
            print("  ✘ Troll 版仍引用 MSHookMessageEx，TrollStore 下会崩")
            ok = False
        if not r["has_loader"]:
            print("  ✘ 没有 +load 兜底")
            ok = False

    print("\n" + ("全部通过 ✔" if ok else "存在问题 ✘"))
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
