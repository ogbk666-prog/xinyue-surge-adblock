package de.robv.android.xposed;

/** 编译期 stub。 */
public class XposedBridge {
    public static void log(String text) {}
    public static void log(Throwable t) {}
}