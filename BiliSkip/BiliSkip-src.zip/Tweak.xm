// BiliSkip —— 哔哩哔哩自动空降（SponsorBlock / bsbsb.top 数据）
//
// 思路：
//   1. hook NSURLSession 的所有任务创建点，从 URL 里抠出 bvid / cid；
//   2. 拿到新的 bvid 就去 bsbsb.top 拉标注片段，缓存在内存里；
//   3. hook AVPlayer 的周期时间观察器，在播放回调里比对当前秒数；
//   4. 落进标注段就 seek 到段尾，弹一条 toast 告诉用户跳过了什么。
//
// 编译：zig cc -target aarch64-ios.14.0（Logos -c generator=internal，TrollStore 免 substrate）

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <objc/runtime.h>

#define BS_LOG(fmt, ...) NSLog(@"[BiliSkip] " fmt, ##__VA_ARGS__)

#pragma mark - 配置

static NSString *const kApiBase = @"https://www.bsbsb.top/api/skipSegments";
static NSString *const kApiHostMark = @"bsbsb.top";

// 允许的类别；留空表示全都收
static NSArray<NSString *> *kBiliSkipCategories(void) {
    return @[@"sponsor", @"selfpromo", @"interaction"];
}

// 只处理自动跳这一档
static NSArray<NSString *> *kBiliSkipActions(void) {
    return @[@"skip"];
}

static const double kTailGuard = 1.0;    // 距离段尾不足 1 秒就不再触发
static const double kMinLength = 1.5;    // 段太短（<1.5s）忽略
static const double kSeekCooldown = 2.0; // 一次 seek 后 2 秒内不再跳

#pragma mark - Toast

static void BSShowToast(NSString *text) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *win = nil;
        if (@available(iOS 13.0, *)) {
            for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
                if (![scene isKindOfClass:[UIWindowScene class]]) continue;
                for (UIWindow *w in ((UIWindowScene *)scene).windows) {
                    if (w.isKeyWindow) { win = w; break; }
                }
                if (win) break;
            }
        }
        if (!win) win = UIApplication.sharedApplication.keyWindow;
        if (!win) return;

        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 280, 48)];
        label.text = text;
        label.textColor = [UIColor whiteColor];
        label.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.88];
        label.font = [UIFont boldSystemFontOfSize:13];
        label.textAlignment = NSTextAlignmentCenter;
        label.numberOfLines = 2;
        label.layer.cornerRadius = 12;
        label.clipsToBounds = YES;
        label.alpha = 0;
        label.center = CGPointMake(win.bounds.size.width / 2.0, win.bounds.size.height * 0.78);
        [win addSubview:label];

        [UIView animateWithDuration:0.18 animations:^{
            label.alpha = 1.0;
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.35 delay:2.0 options:0 animations:^{
                label.alpha = 0.0;
            } completion:^(BOOL done) {
                [label removeFromSuperview];
            }];
        }];
    });
}

#pragma mark - 核心

@interface BiliSkipCore : NSObject
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSArray<NSDictionary *> *> *cache;
@property (nonatomic, strong) NSMutableSet<NSString *> *inflight;
@property (nonatomic, copy) NSString *activeBvid;
@property (nonatomic, copy) NSString *activeCid;
@property (nonatomic, strong) NSArray<NSDictionary *> *activeSegments;
@property (nonatomic, assign) double lastSeekAt;
@property (nonatomic, assign) NSInteger skippedTotal;
+ (instancetype)shared;
- (void)noteURL:(NSString *)url;
- (void)tickTime:(double)seconds player:(AVPlayer *)player;
- (BOOL)enabled;
@end

@implementation BiliSkipCore

+ (instancetype)shared {
    static BiliSkipCore *inst;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ inst = [BiliSkipCore new]; });
    return inst;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _cache = [NSMutableDictionary new];
        _inflight = [NSMutableSet new];
        _activeSegments = @[];
        _lastSeekAt = 0;
    }
    return self;
}

- (BOOL)enabled {
    // 没设置过就走默认开；用户可以在设置里关掉
    NSNumber *v = [[NSUserDefaults standardUserDefaults] objectForKey:@"BiliSkip.enabled"];
    return v ? [v boolValue] : YES;
}

#pragma mark bvid 提取

static NSString *BSExtract(NSString *url, NSString *key) {
    if (url.length == 0) return nil;
    NSString *pattern = [NSString stringWithFormat:@"[?&]%@=([^&#]+)", key];
    NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:nil];
    NSTextCheckingResult *m = [re firstMatchInString:url options:0 range:NSMakeRange(0, url.length)];
    if (!m) return nil;
    return [url substringWithRange:[m rangeAtIndex:1]];
}

- (void)noteURL:(NSString *)url {
    if (![self enabled]) return;
    if (url.length == 0) return;

    // 自己打 API 的请求不要再进来
    if ([url rangeOfString:kApiHostMark].location != NSNotFound) return;

    NSString *bvid = BSExtract(url, @"bvid");
    if (!bvid) {
        // /video/BVxxxx 这种路径形式
        NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"(BV[0-9A-Za-z]{10})" options:0 error:nil];
        NSTextCheckingResult *m = [re firstMatchInString:url options:0 range:NSMakeRange(0, url.length)];
        if (m) bvid = [url substringWithRange:[m rangeAtIndex:1]];
    }
    if (!bvid) return;

    if (self.activeBvid && [self.activeBvid isEqualToString:bvid]) return;

    NSString *cid = BSExtract(url, @"cid");

    BS_LOG("发现视频 bvid=%@ cid=%@", bvid, cid ?: @"-");
    self.activeBvid = bvid;
    self.activeCid = cid;
    self.activeSegments = @[];
    [self loadForBvid:bvid cid:cid];
}

#pragma mark 拉标注

- (void)loadForBvid:(NSString *)bvid cid:(NSString *)cid {
    if (!bvid) return;

    NSArray<NSDictionary *> *hit = self.cache[bvid];
    if (hit) {
        self.activeSegments = [self filterSegments:hit cid:cid];
        BS_LOG("%@ 命中缓存 %lu 段", bvid, (unsigned long)self.activeSegments.count);
        return;
    }

    if ([self.inflight containsObject:bvid]) return;
    [self.inflight addObject:bvid];

    NSString *encoded = [bvid stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
    NSString *full = [NSString stringWithFormat:@"%@?videoID=%@", kApiBase, encoded];
    NSURL *u = [NSURL URLWithString:full];
    if (!u) { [self.inflight removeObject:bvid]; return; }

    BS_LOG("请求 %@", full);

    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:u
        completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
            [self.inflight removeObject:bvid];
            if (err || data.length == 0) {
                BS_LOG("%@ 拉取失败 %@", bvid, err.localizedDescription ?: @"空响应");
                return;
            }
            id obj = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            if (![obj isKindOfClass:[NSArray class]]) {
                BS_LOG("%@ 返回不是数组，可能没标注", bvid);
                return;
            }
            NSArray *raw = (NSArray *)obj;
            self.cache[bvid] = raw;
            BS_LOG("%@ 拿到 %lu 段", bvid, (unsigned long)raw.count);

            if (self.activeBvid && [self.activeBvid isEqualToString:bvid]) {
                self.activeSegments = [self filterSegments:raw cid:self.activeCid];
                BS_LOG("当前视频生效 %lu 段", (unsigned long)self.activeSegments.count);
                if (self.activeSegments.count > 0) {
                    BSShowToast([NSString stringWithFormat:@"空降助手\n本视频有 %lu 处推广", (unsigned long)self.activeSegments.count]);
                }
            }
        }];
    [task resume];
}

- (NSArray<NSDictionary *> *)filterSegments:(NSArray *)raw cid:(NSString *)cid {
    if (![raw isKindOfClass:[NSArray class]]) return @[];
    NSMutableArray *out = [NSMutableArray new];
    NSArray *cats = kBiliSkipCategories();
    NSArray *acts = kBiliSkipActions();

    for (id item in raw) {
        if (![item isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *d = (NSDictionary *)item;

        NSArray *seg = d[@"segment"];
        if (![seg isKindOfClass:[NSArray class]] || seg.count < 2) continue;
        double start = [seg[0] doubleValue];
        double end = [seg[1] doubleValue];
        if (end - start < kMinLength) continue;

        NSString *cat = d[@"category"];
        if (cats.count && cat && ![cats containsObject:cat]) continue;

        NSString *act = d[@"actionType"];
        if (acts.count && act && ![acts containsObject:act]) continue;

        NSString *scid = d[@"cid"] ? [d[@"cid"] description] : nil;
        if (cid && scid && ![scid isEqualToString:cid]) continue;

        [out addObject:@{ @"start": @(start), @"end": @(end), @"category": cat ?: @"sponsor" }];
    }

    [out sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        return [a[@"start"] compare:b[@"start"]];
    }];
    return out;
}

#pragma mark 播放时钟

- (void)tickTime:(double)seconds player:(AVPlayer *)player {
    if (![self enabled]) return;
    if (!player) return;
    if (self.activeSegments.count == 0) return;
    if (seconds <= 0) return;

    double now = CFAbsoluteTimeGetCurrent();
    if (now - self.lastSeekAt < kSeekCooldown) return;

    NSString *current = self.activeSegments.firstObject[@"category"];
    (void)current;

    for (NSDictionary *s in self.activeSegments) {
        double start = [s[@"start"] doubleValue];
        double end = [s[@"end"] doubleValue];

        // 落在段内（留一点段尾余量，避免刚好在边界反复触发）
        if (seconds >= start && seconds < end - kTailGuard) {
            self.lastSeekAt = now;
            self.skippedTotal += 1;

            CMTime target = CMTimeMakeWithSeconds(end, NSEC_PER_SEC);
            [player seekToTime:target toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];

            NSString *label = [self categoryLabel:s[@"category"]];
            BS_LOG("跳过 [%@] %.1f -> %.1f", label, seconds, end);
            BSShowToast([NSString stringWithFormat:@"已跳过%@ %@ → %@",
                         label, [self mmss:start], [self mmss:end]]);
            return;
        }
    }
}

- (NSString *)categoryLabel:(NSString *)cat {
    static NSDictionary *map;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        map = @{
            @"sponsor": @"推广",
            @"selfpromo": @"自我推广",
            @"interaction": @"三连提示",
            @"intro": @"开场",
            @"outro": @"结尾",
            @"preview": @"预览",
            @"filler": @"填充",
            @"poi_highlight": @"看点",
        };
    });
    return map[cat] ?: (cat ?: @"片段");
}

- (NSString *)mmss:(double)sec {
    int total = (int)sec;
    return [NSString stringWithFormat:@"%d:%02d", total / 60, total % 60];
}

@end

#pragma mark - Hook：抓 bvid

%hook NSURLSession

- (NSURLSessionDataTask *)dataTaskWithURL:(NSURL *)url {
    [[BiliSkipCore shared] noteURL:url.absoluteString];
    return %orig;
}

- (NSURLSessionDataTask *)dataTaskWithURL:(NSURL *)url completionHandler:(void (^)(NSData *, NSURLResponse *, NSError *))completionHandler {
    [[BiliSkipCore shared] noteURL:url.absoluteString];
    return %orig;
}

- (NSURLSessionDataTask *)dataTaskWithRequest:(NSURLRequest *)request {
    [[BiliSkipCore shared] noteURL:request.URL.absoluteString];
    return %orig;
}

- (NSURLSessionDataTask *)dataTaskWithRequest:(NSURLRequest *)request completionHandler:(void (^)(NSData *, NSURLResponse *, NSError *))completionHandler {
    [[BiliSkipCore shared] noteURL:request.URL.absoluteString];
    return %orig;
}

- (NSURLSessionDataTask *)dataTaskWithRequest:(NSURLRequest *)request delegate:(id)delegate {
    [[BiliSkipCore shared] noteURL:request.URL.absoluteString];
    return %orig;
}

- (NSURLSessionDownloadTask *)downloadTaskWithURL:(NSURL *)url {
    [[BiliSkipCore shared] noteURL:url.absoluteString];
    return %orig;
}

%end

#pragma mark - Hook：播放时钟

%hook AVPlayer

- (id)addPeriodicTimeObserverForInterval:(CMTime)interval
                                   queue:(dispatch_queue_t)queue
                              usingBlock:(void (^)(CMTime))block {
    AVPlayer *__weak weakPlayer = self;
    void (^wrapped)(CMTime) = ^(CMTime time) {
        if (block) block(time);
        double seconds = CMTimeGetSeconds(time);
        if (!isnan(seconds) && !isinf(seconds)) {
            [[BiliSkipCore shared] tickTime:seconds player:weakPlayer];
        }
    };
    return %orig(interval, queue, wrapped);
}

%end

#pragma mark - 入口

%ctor {
    @autoreleasepool {
        NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"";
        BOOL isBili = [bid isEqualToString:@"tv.danmaku.bilianime"] ||
                      [bid hasPrefix:@"tv.danmaku"];

        BS_LOG("载入 bundle=%@ 是否B站=%@", bid, isBili ? @"是" : @"否");

        if (!isBili) return;

        NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
        if ([d objectForKey:@"BiliSkip.enabled"] == nil) {
            [d setBool:YES forKey:@"BiliSkip.enabled"];
            [d synchronize];
        }

        BS_LOG("已启用，等待播放器");
    }
}
